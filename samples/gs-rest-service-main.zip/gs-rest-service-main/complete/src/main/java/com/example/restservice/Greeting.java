package com.example.restservice;

public record Greeting(long id, String content) { }
